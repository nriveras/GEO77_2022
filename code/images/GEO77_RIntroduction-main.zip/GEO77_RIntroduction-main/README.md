# GEO77_RIntroduction
Presentation and Data for the GEO77 class on R 

This is the depository for the data on the GEO77 class with the data and the Rmarkdown files of the presentation

1) The "Exercice" folder contains the data to used for the exercices as the script for the first part of the class. The exported csv iles of the exercice ( final answer) is in the main folder under the name "Bodendaten_final.csv".

2) The "Presentation_Export" is the file that contains the file bookmarkdown file and the link to the book is the "GEO77_R_Itroduction" in the main folder of the project.

3) The "Report" folder contains the Rmardown orginal folder.
